extends Area2D

func _ready() -> void:
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body.name == "Spinny":
		var remaining_gems := get_tree().get_nodes_in_group("gems").size()
		
		if remaining_gems == 0:
			SceneManager.load_next_level()
		else:
			SceneManager.flash_message("LOCKED! %d GEMS LEFT!" % remaining_gems, Color.ORANGE_RED)
			SceneManager.apply_shake(4.0)
