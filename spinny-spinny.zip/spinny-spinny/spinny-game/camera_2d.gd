extends Camera2D

@export var decay := 5.0 # How fast the shake stops
var shake_strength := 0.0

func _process(delta: float) -> void:
	if shake_strength > 0:
		shake_strength = lerpf(shake_strength, 0.0, decay * delta)
		offset = Vector2(
			randf_range(-shake_strength, shake_strength),
			randf_range(-shake_strength, shake_strength)
		)
	else:
		offset = Vector2.ZERO

func apply_shake(power: float) -> void:
	shake_strength = clampf(power, 0.0, 15.0)
