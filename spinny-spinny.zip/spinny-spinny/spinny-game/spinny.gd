extends RigidBody2D

@export var max_power := 1500.0
@export var charge_rate := 1800.0
@export var stop_speed := 15.0
@export var margin := 48.0
@export var curve_force := 600.0
@export var use_manual_spawn := false # Bocka för denna i Inspector om du vill placera bollen manuellt!

var teleport_requested := false
var teleport_pos: Vector2
var charge := 0.0
var charge_dir := 1.0
var charging := false
var launched := false
var can_air_dash := true
var launch_timer := 0.0
var reset_requested := false
var start_pos: Vector2

@onready var sprite: Sprite2D = $Sprite2D
@onready var arrow: Line2D = $Arrow

func _ready() -> void:
	if use_manual_spawn:
		start_pos = global_position
	else:
		start_pos = get_centre_left()
		global_position = start_pos
		
	can_sleep = false
	
	# Enable collision detection so Spinny knows when it hits a wall
	contact_monitor = true
	max_contacts_reported = 4
	if not body_entered.is_connected(_on_wall_hit):
		body_entered.connect(_on_wall_hit)

func teleport_to(target_pos: Vector2) -> void:
	teleport_pos = target_pos
	teleport_requested = true

func get_centre_left() -> Vector2:
	var screen_size := get_viewport().get_visible_rect().size
	var screen_point := Vector2(margin, screen_size.y / 2.0)
	return get_viewport().get_canvas_transform().affine_inverse() * screen_point

func _process(delta: float) -> void:
	# Animate the rolling shader based on Spinny's velocity
	if sprite.material is ShaderMaterial:
		var current_offset: Vector2 = sprite.material.get_shader_parameter("rolling_offset")
		sprite.material.set_shader_parameter("rolling_offset", current_offset + linear_velocity * delta * 0.002)

	if launched:
		handle_midair_inputs(delta)
		launch_timer += delta
		if launch_timer > 0.3 and linear_velocity.length() < stop_speed:
			reset()
		return

	# Calculate aiming direction toward the mouse
	var dir := (get_global_mouse_position() - global_position).normalized()
	update_trajectory(dir)
	arrow.global_rotation = dir.angle()

	# Input 1 (Pre-launch): Hold Left Click to oscillate charge, release to launch
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		charging = true
		charge += charge_rate * charge_dir * delta
		if charge >= max_power:
			charge = max_power
			charge_dir = -1.0
		elif charge <= 0.0:
			charge = 0.0
			charge_dir = 1.0
			
		arrow.default_color = Color.WHITE.lerp(Color.ORANGE_RED, charge / max_power)
	elif charging:
		launch(dir * charge)

	# Input 2 (Pre-launch): Right Click to cancel a charge
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) and charging:
		charging = false
		charge = 0.0
		charge_dir = 1.0
		arrow.default_color = Color.WHITE

func update_trajectory(dir: Vector2) -> void:
	var space_state := get_world_2d().direct_space_state
	var max_dist := 100.0 + (charge / max_power) * 300.0
	
	# First ray: from Spinny towards the mouse
	var query := PhysicsRayQueryParameters2D.create(global_position, global_position + dir * max_dist)
	query.exclude = [self.get_rid()]
	var result := space_state.intersect_ray(query)
	
	if result:
		var hit_pos: Vector2 = result.position
		var normal: Vector2 = result.normal
		var bounce_dir := dir.bounce(normal)
		
		# How much distance is left after the bounce?
		var remaining_dist = max_dist - global_position.distance_to(hit_pos)
		
		if remaining_dist > 0:
			# Second ray: calculate the bounce reflection line segment
			var query2 := PhysicsRayQueryParameters2D.create(hit_pos + normal * 2.0, hit_pos + normal * 2.0 + bounce_dir * remaining_dist)
			query2.exclude = [self.get_rid()]
			var result2 := space_state.intersect_ray(query2)
			
			var end_pos = result2.position if result2 else (hit_pos + normal * 2.0 + bounce_dir * remaining_dist)
			
			# Convert global points to local coordinates for the Line2D arrow node
			var local_hit = arrow.to_local(hit_pos)
			var local_end = arrow.to_local(end_pos)
			arrow.points = PackedVector2Array([Vector2.ZERO, local_hit, local_end])
			return

	# Default straight line if no wall is hit within range
	arrow.points = PackedVector2Array([Vector2.ZERO, Vector2(max_dist, 0)])

func handle_midair_inputs(_delta: float) -> void:
	# Input 1 (Mid-air): Hold Left Click to curve Spinny's path
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and linear_velocity.length() > 50.0:
		var perp := Vector2(-linear_velocity.y, linear_velocity.x).normalized()
		apply_central_force(perp * curve_force)

	# Input 2 (Mid-air): Right Click for a one-time mid-air redirect towards the mouse
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) and can_air_dash:
		can_air_dash = false
		var to_mouse := (get_global_mouse_position() - global_position).normalized()
		linear_velocity = to_mouse * (linear_velocity.length() * 0.8)
		angular_velocity = 60.0
		SceneManager.apply_shake(6.0)

func launch(impulse: Vector2) -> void:
	print("Launching with power: ", impulse.length())
	charging = false
	launched = true
	can_air_dash = true
	launch_timer = 0.0
	arrow.visible = false
	apply_central_impulse(impulse)
	angular_velocity = 40.0
	SceneManager.play_tone(329.63, 0.12)
	SceneManager.add_shot()

func reset() -> void:
	print("Reset")
	reset_requested = true
	launched = false
	charging = false
	charge = 0.0
	charge_dir = 1.0
	arrow.default_color = Color.WHITE
	arrow.visible = true

func _integrate_forces(state: PhysicsDirectBodyState2D) -> void:
	if reset_requested:
		state.transform = Transform2D(0, start_pos)
		state.linear_velocity = Vector2.ZERO
		state.angular_velocity = 0.0
		reset_requested = false
	elif teleport_requested:
		state.transform = Transform2D(state.transform.get_rotation(), teleport_pos)
		teleport_requested = false

func _on_wall_hit(_body: Node) -> void:
	if launched:
		SceneManager.apply_shake(linear_velocity.length() * 0.012)
