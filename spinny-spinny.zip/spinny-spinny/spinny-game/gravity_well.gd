extends Area2D

@export var pull_strength := 900.0 # Make negative (-900.0) for a repulsor field!
var target_body: RigidBody2D = null

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _on_body_entered(body: Node2D) -> void:
	if body is RigidBody2D and body.name == "Spinny":
		target_body = body

func _on_body_exited(body: Node2D) -> void:
	if body == target_body:
		target_body = null

func _physics_process(_delta: float) -> void:
	if target_body:
		var dir := (global_position - target_body.global_position).normalized()
		target_body.apply_central_force(dir * pull_strength)
