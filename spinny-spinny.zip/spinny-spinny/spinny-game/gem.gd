extends Area2D

func _ready() -> void:
	add_to_group("gems")
	body_entered.connect(_on_body_entered)
	# Tell SceneManager to recount gems once this gem enters the level
	SceneManager.call_deferred("update_gem_ui")

func _on_body_entered(body: Node2D) -> void:
	if body is RigidBody2D and body.name == "Spinny":
		SceneManager.apply_shake(3.0)
		SceneManager.play_tone(880.0, 0.18)
		# Remove from group first so the count is accurate immediately
		remove_from_group("gems")
		SceneManager.update_gem_ui()
		
		var remaining_gems := get_tree().get_nodes_in_group("gems").size()
		if remaining_gems == 0:
			SceneManager.flash_message("ALL GEMS CLEARED!\nGO TO EXIT!", Color.GREEN_YELLOW)
			
		queue_free()
