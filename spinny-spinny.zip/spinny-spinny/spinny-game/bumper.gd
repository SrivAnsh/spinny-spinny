extends Area2D

@export var bounce_power := 1100.0

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body is RigidBody2D and body.name == "Spinny":
		# Calculate direction away from the bumper center
		var push_dir := (body.global_position - global_position).normalized()
		body.linear_velocity = push_dir * bounce_power
		SceneManager.play_tone(587.33, 0.15)
		# Juice: Screen shake + bumper scale punch
		SceneManager.apply_shake(8.0)
		
		var tween := create_tween()
		tween.tween_property(self, "scale", Vector2(1.4, 1.4), 0.05)
		tween.tween_property(self, "scale", Vector2(1.0, 1.0), 0.12)
