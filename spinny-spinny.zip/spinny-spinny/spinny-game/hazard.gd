extends Area2D

@export var move_offset := Vector2(0, 150)
@export var move_duration := 1.5

func _ready() -> void:
	body_entered.connect(_on_body_entered)
	
	# If move_offset isn't (0,0), smoothly ping-pong back and forth
	if move_offset != Vector2.ZERO:
		var start_pos := global_position
		var end_pos := start_pos + move_offset
		
		var tween := create_tween().set_loops()
		tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
		tween.tween_property(self, "global_position", end_pos, move_duration)
		tween.tween_property(self, "global_position", start_pos, move_duration)

func _on_body_entered(body: Node2D) -> void:
	if body is RigidBody2D and body.name == "Spinny":
		print("Hit hazard! Resetting position...")
		SceneManager.apply_shake(12.0)
		SceneManager.play_tone(130.81, 0.3)
		if body.has_method("reset"):
			body.reset()
