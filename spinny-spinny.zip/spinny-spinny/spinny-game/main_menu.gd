extends Control

@onready var play_button: Button = $PlayButton
@onready var quit_button: Button = $QuitButton

func _ready() -> void:
	play_button.pressed.connect(_on_play_pressed)
	quit_button.pressed.connect(_on_quit_pressed)
	
	# Gentle floating animation on the title or play button
	var tween := create_tween().set_loops()
	tween.tween_property(play_button, "scale", Vector2(1.05, 1.05), 0.6).set_trans(Tween.TRANS_SINE)
	tween.tween_property(play_button, "scale", Vector2(1.0, 1.0), 0.6).set_trans(Tween.TRANS_SINE)

func _on_play_pressed() -> void:
	SceneManager.start_game()

func _on_quit_pressed() -> void:
	get_tree().quit()
