extends Area2D

@export var target_portal: Area2D
var on_cooldown := false

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if on_cooldown or not target_portal:
		return

	if body is RigidBody2D and body.name == "Spinny":
		target_portal.trigger_cooldown()
		trigger_cooldown()
		SceneManager.play_tone(659.25, 0.2)
		if body.has_method("teleport_to"):
			body.teleport_to(target_portal.global_position)
			SceneManager.apply_shake(5.0)

func trigger_cooldown() -> void:
	on_cooldown = true
	await get_tree().create_timer(0.4).timeout
	on_cooldown = false
