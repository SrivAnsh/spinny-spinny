extends CanvasLayer

var levels: Array[String] = [
	'res://Levels/level_1.tscn',
	"res://Levels/level_2.tscn",
	"res://Levels/level_3.tscn"
]
var shots_taken := 0
var total_shots := 0
var gem_label: Label
var flash_label: Label
var hud_label: Label
var is_transitioning := false
var current_level_index := 0
var color_rect: ColorRect
var shake_strength := 0.0
var shake_decay := 8.0
var flash_tween: Tween

func _ready() -> void:
	layer = 100
	
	# Fade overlay rectangle
	color_rect = ColorRect.new()
	color_rect.color = Color(0, 0, 0, 0)
	color_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	color_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(color_rect)
	
	if ResourceLoader.exists("res://hud.tscn"):
		var hud_scene = load("res://hud.tscn")
		if hud_scene:
			var hud_node = hud_scene.instantiate()
			if hud_node:
				add_child(hud_node)
				hud_label = hud_node.get_node_or_null("ShotLabel") as Label
				gem_label = hud_node.get_node_or_null("GemLabel") as Label
				flash_label = hud_node.get_node_or_null("FlashLabel") as Label
				if hud_label:
					hud_label.text = "Shots: 0"
				if flash_label:
					flash_label.modulate.a = 0.0 # Hide flash label on start
				call_deferred("update_gem_ui")
	
	var current_scene_file = get_tree().current_scene.scene_file_path if get_tree().current_scene else ""
	var is_menu = "MainMenu" in current_scene_file
	if hud_label: hud_label.visible = not is_menu
	if gem_label: gem_label.visible = not is_menu

func add_shot() -> void:
	shots_taken += 1
	if hud_label:
		hud_label.text = "Shots: %d" % shots_taken

func _process(delta: float) -> void:
	if shake_strength > 0.0:
		shake_strength = lerpf(shake_strength, 0.0, shake_decay * delta)
		var shake_offset := Vector2(
			randf_range(-shake_strength, shake_strength),
			randf_range(-shake_strength, shake_strength)
		)
		get_viewport().canvas_transform.origin = shake_offset
	else:
		get_viewport().canvas_transform.origin = Vector2.ZERO

func apply_shake(power: float) -> void:
	shake_strength = clampf(power, 0.0, 12.0)

func start_game() -> void:
	shots_taken = 0
	total_shots = 0
	if hud_label:
		hud_label.text = "Shots: 0"
	current_level_index = 0
	fade_to_scene(levels[current_level_index])

# 2. Update your fade_to_scene function to hide/show the HUD automatically:
func fade_to_scene(scene_path: String) -> void:
	if is_transitioning:
		return
	is_transitioning = true
	
	shake_strength = 0.0
	get_viewport().canvas_transform.origin = Vector2.ZERO
	color_rect.mouse_filter = Control.MOUSE_FILTER_STOP
	
	var tween := create_tween()
	tween.tween_property(color_rect, "color:a", 1.0, 0.35).set_trans(Tween.TRANS_SINE)
	await tween.finished
	
	get_tree().change_scene_to_file(scene_path)
	
	# Hide HUD if we are on the Main Menu, show it if we are in a level
	var is_menu = "MainMenu" in scene_path
	if hud_label: hud_label.visible = not is_menu
	if gem_label: gem_label.visible = not is_menu
	
	# Wait one frame for the new scene's gems to load, then refresh the HUD!
	await get_tree().process_frame
	update_gem_ui()
	
	var tween_in := create_tween()
	tween_in.tween_property(color_rect, "color:a", 0.0, 0.35).set_trans(Tween.TRANS_SINE)
	await tween_in.finished
	
	color_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	is_transitioning = false

func show_level_summary() -> void:
	get_tree().paused = true
	play_tone(1046.50, 0.3) # High C victory chime
	
	var is_final_level := (current_level_index + 1) >= levels.size()
	
	# Dimmed background overlay
	var overlay := ColorRect.new()
	overlay.color = Color(0, 0, 0, 0.75)
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(overlay)
	
	# Centered UI layout container
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.add_child(center)
	
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(360, 230)
	center.add_child(panel)
	
	var vbox := VBoxContainer.new()
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	vbox.add_theme_constant_override("separation", 16)
	panel.add_child(vbox)
	
	# Title Label
	var title := Label.new()
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	title.text = "GAME COMPLETE!" if is_final_level else ("LEVEL %d CLEARED!" % (current_level_index + 1))
	title.modulate = Color.GOLD if is_final_level else Color.GREEN_YELLOW
	vbox.add_child(title)
	
	# Stats Label
	var stats := Label.new()
	stats.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	stats.add_theme_font_size_override("font_size", 18)
	if is_final_level:
		stats.text = "Level Shots: %d\nTotal Run Shots: %d" % [shots_taken, total_shots]
	else:
		stats.text = "Shots Taken: %d" % shots_taken
	vbox.add_child(stats)
	
	# Next / Main Menu Button
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(200, 44)
	btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	btn.text = "Return to Main Menu" if is_final_level else "Next Level  ->"
	vbox.add_child(btn)
	
	# Pop-in animation (set_pause_mode allows tweens to run while the tree is paused)
	panel.scale = Vector2(0.7, 0.7)
	panel.pivot_offset = Vector2(180, 115)
	var pop_tween := create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	pop_tween.tween_property(panel, "scale", Vector2.ONE, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	
	btn.pressed.connect(func():
		get_tree().paused = false
		overlay.queue_free()
		
		shots_taken = 0
		if hud_label:
			hud_label.text = "Shots: 0"
			
		current_level_index += 1
		if current_level_index < levels.size():
			fade_to_scene(levels[current_level_index])
		else:
			fade_to_scene("res://MainMenu.tscn")
	)
		
func update_gem_ui() -> void:
	if not gem_label:
		return
	var remaining := get_tree().get_nodes_in_group("gems").size()
	if remaining > 0:
		gem_label.text = "Gems left: %d" % remaining
	else:
		gem_label.text = "Goal Unlocked!"

func flash_message(msg: String, color: Color = Color.GOLD) -> void:
	if not flash_label:
		return
	if flash_tween and flash_tween.is_valid():
		flash_tween.kill()
		
	flash_label.text = msg
	flash_label.modulate = color
	flash_label.modulate.a = 0.0
	flash_label.scale = Vector2(0.5, 0.5)
	flash_label.pivot_offset = flash_label.size / 2.0
	
	# Pop in, hold for 1.2 seconds, then fade out smoothly
	flash_tween = create_tween()
	flash_tween.set_parallel(true)
	flash_tween.tween_property(flash_label, "scale", Vector2(1.0, 1.0), 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	flash_tween.tween_property(flash_label, "modulate:a", 1.0, 0.15)
	flash_tween.chain().tween_interval(1.2)
	flash_tween.chain().tween_property(flash_label, "modulate:a", 0.0, 0.4)
	

func play_sfx(file_path: String, pitch_min := 0.9, pitch_max := 1.1) -> void:
	if not ResourceLoader.exists(file_path):
		return
	var player := AudioStreamPlayer.new()
	player.stream = load(file_path)
	player.pitch_scale = randf_range(pitch_min, pitch_max)
	# Ensure sound still plays even if the level summary screen pauses the tree
	player.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(player)
	player.play()
	player.finished.connect(player.queue_free)


func play_tone(freq: float = 440.0, duration: float = 0.12, volume_db: float = -10.0) -> void:
	var player := AudioStreamPlayer.new()
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = 22050.0
	gen.buffer_length = duration
	player.stream = gen
	player.volume_db = volume_db
	player.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(player)
	player.play()
	
	var playback := player.get_stream_playback() as AudioStreamGeneratorPlayback
	var frames := int(gen.mix_rate * duration)
	var phase := 0.0
	var increment := freq / gen.mix_rate
	
	for i in range(frames):
		# Linear fade-out envelope so the sound doesn't click at the end
		var env := 1.0 - (float(i) / frames)
		var sample := sin(phase * TAU) * env
		playback.push_frame(Vector2(sample, sample))
		phase = fmod(phase + increment, 1.0)
		
	await get_tree().create_timer(duration).timeout
	player.queue_free()

func load_next_level() -> void:
	if is_transitioning:
		return
	total_shots += shots_taken
	show_level_summary()
